export interface PanelIDProps{
    id: string
}