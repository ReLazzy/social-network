export const REG_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
export const REG_PASS = /^[A-Za-z0-9]{6,}$/;
export const PF = 'http://45.141.76.248:8800/images/';
export const API_URL = 'http://45.141.76.248:8800/api';
